<?php

include_once "errorCode.php";

class SHA1
{
	public function getSHA1($token, $timestamp, $nonce, $encrypt_msg)
	{
		try {
			$array = array($encrypt_msg, $token, $timestamp, $nonce);
			sort($array, SORT_STRING);
			$str = implode($array);
			return array(ErrorCode::$OK, sha1($str));
		} catch (Exception $e) {
            Log::e($e->getMessage());
			return array(ErrorCode::$ComputeSignatureError, null);
		}
	}

}


?>